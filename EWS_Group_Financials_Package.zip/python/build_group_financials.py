"""
build_group_financials.py

ETL skeleton for EWS group financials.

Workflow:
1. Read group matching (group_id, year, edrpou list).
2. Read raw financials exported from ClientProfile in wide format.
3. Normalize wide financials to long format.
4. Attach group_id by year-specific matching.
5. Aggregate group financials by group_id/report_date/report_form/line_code.
6. Calculate indicators.
7. Export Excel with company-level and group-level financials.

This script is intentionally database-neutral. In production, replace CSV reads with:
- SQL Server ClientProfile.finrep stored procedure calls;
- Oracle credit-contract source for EWS integration.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple


FINANCIAL_CODES = [
    "1000","1001","1002","1005","1010","1011","1012","1015","1020","1030","1035","1040","1045","1050","1060","1065",
    "1090","1095","1100","1101","1102","1103","1104","1110","1115","1120","1125","1130","1135","1136","1140","1145",
    "1155","1160","1165","1166","1167","1170","1180","1190","1195","1200","1300","1400","1405","1410","1415","1420",
    "1425","1430","1435","1495","1500","1505","1510","1515","1520","1525","1530","1535","1540","1545","1595м","1595",
    "1600","1605","1610","1615","1620","1621","1625","1630","1635","1640","1645","1650","1660","1665","1670","1690",
    "1695","1700","1800","1900","2000","2010","2011","2012","2013","2014","2050","2070","2090","2095","2105","2110",
    "2111","2112","2120","2121","2122","2130","2150","2160","2165","2180","2190","2195","2200","2220","2240","2250",
    "2255","2270","2275","2280","2285","2290","2295","2300","2305","2310","2350","2355","2400","2405","2410","2415",
    "2445","2450","2455","2460","2465","2500","2505","2510","2515","2520","2550","2600","2605","2610","2615","2650"
]


def parse_number(value: str) -> Optional[float]:
    if value is None:
        return None
    s = str(value).strip()
    if s in {"", "-", "#DIV/0!", "#VALUE!", "#ДІЛЕННЯ/0!", "#ЗНАЧЕННЯ!"}:
        return None
    s = s.replace(" ", "").replace("\u00a0", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def report_year_from_date(report_date: str) -> int:
    # ClientProfile often stores FY2025 as 01.01.2026.
    # For annual reporting dates like 01.01.YYYY, business reporting year is YYYY - 1.
    dt = datetime.strptime(report_date[:10], "%Y-%m-%d")
    if dt.month == 1 and dt.day == 1:
        return dt.year - 1
    return dt.year


def load_matching(path: Path) -> Dict[Tuple[int, str], Dict[str, str]]:
    out: Dict[Tuple[int, str], Dict[str, str]] = {}
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            year = int(row["matching_year"])
            edrpou = str(row["edrpou"]).strip()
            if row.get("inclusion_flag", "1") in {"1", "TRUE", "True", "так", "ТАК"}:
                out[(year, edrpou)] = row
    return out


def normalize_wide(raw_path: Path, matching: Dict[Tuple[int, str], Dict[str, str]]) -> List[dict]:
    long_rows: List[dict] = []
    with raw_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for src in reader:
            edrpou = str(src.get("Код ЄДРПОУ") or src.get("edrpou") or "").strip()
            report_date = src.get("Звітна дата") or src.get("report_date")
            report_form = src.get("Форма звітності") or src.get("report_form")
            year = report_year_from_date(report_date)
            match = matching.get((year, edrpou))
            group_id = match["group_id"] if match else "UNMATCHED"

            for code in FINANCIAL_CODES:
                value = parse_number(src.get(code, ""))
                long_rows.append({
                    "group_id": group_id,
                    "report_date": report_date,
                    "report_year": year,
                    "edrpou": edrpou,
                    "client_name": src.get("Назва клієнта") or src.get("client_name"),
                    "report_form": report_form,
                    "line_code": code,
                    "line_value": value or 0.0,
                })
    return long_rows


def aggregate_group(long_rows: List[dict]) -> List[dict]:
    acc: Dict[Tuple[str, str, int, str, str], float] = {}
    members: Dict[Tuple[str, str, int, str, str], set] = {}

    for r in long_rows:
        if r["group_id"] == "UNMATCHED":
            continue
        key = (r["group_id"], r["report_date"], r["report_year"], r["report_form"], r["line_code"])
        acc[key] = acc.get(key, 0.0) + (r["line_value"] or 0.0)
        members.setdefault(key, set()).add(r["edrpou"])

    out = []
    for key, val in sorted(acc.items()):
        group_id, report_date, year, report_form, line_code = key
        out.append({
            "group_id": group_id,
            "report_date": report_date,
            "report_year": year,
            "report_form": report_form,
            "line_code": line_code,
            "line_value": val,
            "members_count": len(members[key]),
            "members_edrpou": ";".join(sorted(members[key])),
        })
    return out


def get_line(rows: Dict[str, float], code: str) -> float:
    return float(rows.get(code, 0.0) or 0.0)


def safe_div(a: float, b: float) -> Optional[float]:
    if abs(b) < 1e-9:
        return None
    return a / b


def calculate_indicators_for_lines(lines: Dict[str, float], days: int = 365) -> dict:
    revenue = get_line(lines, "2000")
    cogs = get_line(lines, "2050")
    gross_profit = get_line(lines, "2090") - get_line(lines, "2095")
    ebit = get_line(lines, "2190") - get_line(lines, "2195")
    depreciation = get_line(lines, "2515")
    ebitda = ebit + depreciation
    nie = get_line(lines, "2250") - get_line(lines, "2220")
    net_income = get_line(lines, "2350") - get_line(lines, "2355")
    cash = get_line(lines, "1165")
    ar = get_line(lines, "1120") + get_line(lines, "1125")
    inventory = get_line(lines, "1100") + get_line(lines, "1110")
    ap = get_line(lines, "1605") + get_line(lines, "1615")
    total_assets = get_line(lines, "1300")
    equity = get_line(lines, "1495")
    current_assets = get_line(lines, "1195")
    current_liabilities = get_line(lines, "1695")
    debt = get_line(lines, "1510") + get_line(lines, "1515") + get_line(lines, "1600") + get_line(lines, "1610")

    dso = safe_div(ar * days, revenue)
    dio = safe_div(inventory * days, abs(cogs - depreciation))
    dpo = safe_div(ap * days, abs(cogs - depreciation))
    fin_cycle = None if dso is None or dio is None or dpo is None else dso + dio - dpo

    return {
        "revenue": revenue,
        "gross_profit": gross_profit,
        "ebit": ebit,
        "depreciation": depreciation,
        "ebitda": ebitda,
        "nie": nie,
        "net_income": net_income,
        "cash": cash,
        "accounts_receivable": ar,
        "inventory": inventory,
        "accounts_payable": ap,
        "total_assets": total_assets,
        "equity": equity,
        "current_assets": current_assets,
        "current_liabilities": current_liabilities,
        "total_interest_bearing_debt": debt,
        "equity_ratio": safe_div(equity, total_assets),
        "current_ratio": safe_div(current_assets, current_liabilities),
        "net_debt_to_ebitda": safe_div(debt - cash, ebitda) if ebitda > 0 else None,
        "icrm": safe_div(ebitda, abs(nie)) if abs(nie) >= 1 else None,
        "dso_days": dso,
        "dio_days": dio,
        "dpo_days": dpo,
        "financial_cycle_days": fin_cycle,
        "average_capital_need": safe_div(abs(cogs) * fin_cycle, days) if fin_cycle is not None else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--matching", required=True, help="CSV group matching file")
    parser.add_argument("--raw-wide", required=True, help="CSV raw wide financials")
    parser.add_argument("--out-long", required=True, help="Output normalized long CSV")
    parser.add_argument("--out-group", required=True, help="Output aggregated group long CSV")
    args = parser.parse_args()

    matching = load_matching(Path(args.matching))
    long_rows = normalize_wide(Path(args.raw_wide), matching)
    group_rows = aggregate_group(long_rows)

    with Path(args.out_long).open("w", encoding="utf-8-sig", newline="") as f:
        fieldnames = ["group_id","report_date","report_year","edrpou","client_name","report_form","line_code","line_value"]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(long_rows)

    with Path(args.out_group).open("w", encoding="utf-8-sig", newline="") as f:
        fieldnames = ["group_id","report_date","report_year","report_form","line_code","line_value","members_count","members_edrpou"]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(group_rows)


if __name__ == "__main__":
    main()
