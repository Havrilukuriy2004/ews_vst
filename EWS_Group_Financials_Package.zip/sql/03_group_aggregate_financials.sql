/*
03_group_aggregate_financials.sql
Purpose: aggregate company financial rows into group-level rows according to year-specific matching.
*/

-- Step 1. Assign group_id to raw financials using matching-year.
UPDATE r
SET r.group_id = m.group_id
FROM dbo.ews_financials_raw_long r
JOIN dbo.ews_group_matching m
  ON m.edrpou = r.edrpou
 AND m.matching_year = r.report_year
 AND m.inclusion_flag = 1
WHERE r.group_id IS NULL;

-- Step 2. Rebuild group long data for selected year.
DECLARE @ReportYear int = 2025;

DELETE FROM dbo.ews_financials_group_long
WHERE report_year = @ReportYear;

INSERT INTO dbo.ews_financials_group_long (
    group_id,
    group_name,
    report_date,
    report_year,
    report_form,
    line_code,
    line_value,
    members_count,
    members_edrpou,
    aggregation_rule
)
SELECT
    m.group_id,
    MAX(m.group_name) AS group_name,
    r.report_date,
    r.report_year,
    r.report_form,
    r.line_code,
    SUM(COALESCE(r.line_value,0)) AS line_value,
    COUNT(DISTINCT r.edrpou) AS members_count,
    STRING_AGG(CONVERT(nvarchar(max), r.edrpou), N'; ') AS members_edrpou,
    N'SUM' AS aggregation_rule
FROM dbo.ews_financials_raw_long r
JOIN dbo.ews_group_matching m
  ON m.edrpou = r.edrpou
 AND m.matching_year = r.report_year
 AND m.inclusion_flag = 1
WHERE r.report_year = @ReportYear
GROUP BY
    m.group_id,
    r.report_date,
    r.report_year,
    r.report_form,
    r.line_code;

-- Step 3. Example wide view for group-level financials.
-- In production this pivot should be generated from field_codes_catalog.csv.
CREATE OR ALTER VIEW dbo.ews_vw_group_financials_wide AS
SELECT
    group_id AS [Ідентифікатор],
    report_date AS [Звітна дата],
    CAST(group_id AS nvarchar(20)) AS [Код ЄДРПОУ],
    report_form AS [Форма звітності],
    SUM(CASE WHEN line_code = N'1000' THEN line_value ELSE 0 END) AS [1000],
    SUM(CASE WHEN line_code = N'1001' THEN line_value ELSE 0 END) AS [1001],
    SUM(CASE WHEN line_code = N'1002' THEN line_value ELSE 0 END) AS [1002],
    SUM(CASE WHEN line_code = N'1005' THEN line_value ELSE 0 END) AS [1005],
    SUM(CASE WHEN line_code = N'1010' THEN line_value ELSE 0 END) AS [1010],
    SUM(CASE WHEN line_code = N'1011' THEN line_value ELSE 0 END) AS [1011],
    SUM(CASE WHEN line_code = N'1012' THEN line_value ELSE 0 END) AS [1012],
    SUM(CASE WHEN line_code = N'1015' THEN line_value ELSE 0 END) AS [1015],
    SUM(CASE WHEN line_code = N'1020' THEN line_value ELSE 0 END) AS [1020],
    SUM(CASE WHEN line_code = N'1030' THEN line_value ELSE 0 END) AS [1030],
    SUM(CASE WHEN line_code = N'1035' THEN line_value ELSE 0 END) AS [1035],
    SUM(CASE WHEN line_code = N'1040' THEN line_value ELSE 0 END) AS [1040],
    SUM(CASE WHEN line_code = N'1045' THEN line_value ELSE 0 END) AS [1045],
    SUM(CASE WHEN line_code = N'1050' THEN line_value ELSE 0 END) AS [1050],
    SUM(CASE WHEN line_code = N'1060' THEN line_value ELSE 0 END) AS [1060],
    SUM(CASE WHEN line_code = N'1065' THEN line_value ELSE 0 END) AS [1065],
    SUM(CASE WHEN line_code = N'1090' THEN line_value ELSE 0 END) AS [1090],
    SUM(CASE WHEN line_code = N'1095' THEN line_value ELSE 0 END) AS [1095],
    SUM(CASE WHEN line_code = N'1100' THEN line_value ELSE 0 END) AS [1100],
    SUM(CASE WHEN line_code = N'1101' THEN line_value ELSE 0 END) AS [1101]
    -- extend automatically for all codes from field_codes_catalog.csv
FROM dbo.ews_financials_group_long
GROUP BY group_id, report_date, report_form;