# EWS Group Financials Package

Пакет містить технічне завдання, Excel-шаблон і кодові артефакти для збору, нормалізації та агрегації фінансової звітності групи клієнтів.

## Бізнес-вимога

1. Забрати фінансову звітність по двох компаніях / юридичних особах.
2. Для конкретного року застосувати конкретний matching: які ЄДРПОУ входять до групи саме у цьому році.
3. Скласти по групі wide-financials: сума всіх рядків фінзвітності за однаковою звітною датою та формою.
4. Зберегти Excel з:
   - company-level financials;
   - group-level aggregated financials;
   - full financials;
   - ratio / EWS-ready indicators;
   - transformation rules;
   - validation checks.

## Ключовий принцип

Фінансові рядки 1000...2650 агрегуються сумою по учасниках групи. Метадані не сумуються:
- КВЕД групи: основний КВЕД головної компанії або КВЕД компанії з найбільшою виручкою;
- Користувач / версія / дата збереження: ETL metadata;
- ЄДРПОУ групи: synthetic group id або список ЄДРПОУ;
- середня чисельність працівників: сума.

## Вміст архіву

- docs/TZ_Group_Financials_EWS.docx — детальне ТЗ.
- Group_Financials_EWS_Template.xlsx — Excel-шаблон із wide headers, matching, group aggregation, indicators.
- sql/*.sql — SQL Server / Oracle / staging / aggregation scripts.
- python/build_group_financials.py — ETL skeleton.
- vba/ProcessReports_GroupAggregation.bas — VBA skeleton.
- data/field_codes_catalog.csv — каталог рядків фінзвітності.
- data/metric_mapping.csv — мапінг показників.
- extracted_sources/ — витягнуті VBA/SQL джерела з наданих Excel-файлів, якщо доступні.

Generated: 2026-05-18 08:09:02
